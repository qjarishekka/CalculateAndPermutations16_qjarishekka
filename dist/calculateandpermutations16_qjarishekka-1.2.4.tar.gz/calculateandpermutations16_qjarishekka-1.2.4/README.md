# README

## CONTENTS OF THIS FILE

* Introduction
* Requirements
* Installation
* Configuration
* Maintainers

## INTRODUCTION

* This library was made to easy calculate the result of a formula given as a string and calulate fatorial, 
permutations and combinations. Module calc can solve ONLY BASIC MATEMATICS and solve them from left to right.

## REQUIREMENTS

* those modules only require python  3.12.X

## INSTALLATION

* Install as you would normally install a contributed Drupal module. Visit
  https://www.drupal.org/documentation/install/modules-themes/modules-7 for
  further information.


## CONFIGURATION

* The module has no menu or modifiable settings. There is no configuration.

## MAINTAINERS

* Qjari Shekka Calizaya Arce  https://pypi.org/user/qjari/